# Akshitha Vadla - Personal Portfolio Website 🌸

A clean, modern pastel-themed personal portfolio website created using **HTML**, **CSS**, and **JavaScript**.

## 🧠 About
This project is a simple, beginner-friendly responsive web page that showcases personal information, skills, and a sample project.  
It includes sections for Home, About, Skills, Projects, and Contact.

## 🌸 Features
- Fully responsive design  
- Smooth scroll navigation  
- Modern pastel color palette  
- Social links (LinkedIn, GitHub placeholders)

## 🧩 Technologies Used
- HTML5  
- CSS3  
- JavaScript

## 💌 Contact
**Name:** Akshitha Vadla  
**Email:** [akshithavadla24@gmail.com](mailto:akshithavadla24@gmail.com)

---
© 2025 Akshitha Vadla. All rights reserved.
